import Link from "next/link";
import { searchAnime } from "@/lib/anilist";
export default async function Search({searchParams}:{searchParams:Promise<{q?:string}>}){
 const q=(await searchParams).q||"";
 const data=q?await searchAnime(q):{Page:{media:[]}};
 return <main className="section"><div className="container"><h1>🔎 Search Anime</h1><form className="search"><input className="input" name="q" defaultValue={q} placeholder="Masukkan judul anime"/><button className="btn">Cari</button></form>{q&&<p className="muted">Hasil untuk: {q}</p>}<div className="grid">{data.Page.media.map((a:any)=><Link className="card" href={`/anime/${a.id}`} key={a.id}><img className="cover" src={a.coverImage.large}/><div className="pad"><div className="title">{a.title.english||a.title.romaji}</div><div className="muted">{a.seasonYear||"—"} • ⭐ {a.averageScore?`${a.averageScore/10}`:"—"}</div></div></Link>)}</div></div></main>
}