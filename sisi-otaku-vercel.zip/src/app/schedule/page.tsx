import Link from "next/link";
import {weeklySchedule} from "@/lib/anilist";
const days=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
export default async function Schedule(){
 const d=await weeklySchedule(); const rows=d.Page.airingSchedules;
 const groups:any={}; rows.forEach((x:any)=>{const day=days[new Date(x.airingAt*1000).getDay()];(groups[day]??=[]).push(x)});
 return <main className="section"><div className="container"><h1>📅 Jadwal Anime</h1><p className="muted">Jadwal dari data AniList.</p>{days.map(day=><section className="section" key={day}><h2>{day}</h2><div className="grid">{(groups[day]||[]).map((x:any)=><Link className="card" href={`/anime/${x.media.id}`} key={x.media.id+"-"+x.airingAt}><img className="cover" src={x.media.coverImage.medium}/><div className="pad"><div className="title">{x.media.title.romaji}</div><div className="muted">Episode {x.episode} • {new Date(x.airingAt*1000).toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"})}</div></div></Link>)}</div>{!groups[day]?.length&&<div className="notice">Tidak ada data jadwal.</div>}</section>)}</div></main>
}